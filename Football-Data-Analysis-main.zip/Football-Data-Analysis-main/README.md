# Football-Data-Analysis
Using Python tools to analyze football team- or player-wise performance for better team performance
